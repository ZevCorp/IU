// background.js - Comunicador con IU-OS

const WS_URL = 'ws://127.0.0.1:9223';
let socket = null;
let reconnectTimer = null;

function connectToApp() {
    if (socket) return;
    console.log('[I&Ü Extension] Intentando conectar a IU-OS en', WS_URL);
    socket = new WebSocket(WS_URL);

    socket.onopen = () => {
        console.log('[I&Ü Extension] Conectado a IU-OS exitosamente');
        clearTimeout(reconnectTimer);
    };

    socket.onmessage = async (event) => {
        try {
            const req = JSON.parse(event.data);
            if (req.type === 'GET_AFFORDANCES') {
                const results = await extractCurrentTabAffordances();
                socket.send(JSON.stringify({ type: 'AFFORDANCES_RESULT', data: results }));
            }
        } catch (e) {
            console.error('[I&Ü Extension] Error procesando mensaje:', e);
            socket.send(JSON.stringify({ type: 'ERROR', error: e.message }));
        }
    };

    socket.onclose = () => {
        console.log('[I&Ü Extension] Desconectado de IU-OS. Reintentando en 3s...');
        socket = null;
        reconnectTimer = setTimeout(connectToApp, 3000);
    };

    socket.onerror = (err) => {
        // Ignorar para evitar ruido, el close handler se encargará
        if (socket) socket.close();
    };
}

connectToApp();

// Módulo Extractor usando chrome.debugger
async function extractCurrentTabAffordances() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs || tabs.length === 0) throw new Error("No active tab found");
    const tabId = tabs[0].id;
    const target = { tabId };

    try {
        await chrome.debugger.attach(target, '1.3');

        // Habilitar dominios
        await chrome.debugger.sendCommand(target, 'Accessibility.enable');
        await chrome.debugger.sendCommand(target, 'DOM.enable');

        // Extraer árbol de accesibilidad y estructura
        const axRes = await chrome.debugger.sendCommand(target, 'Accessibility.getFullAXTree');
        const nodes = Array.isArray(axRes?.nodes) ? axRes.nodes : [];

        // Obtener el offset absoluto de la ventana en la pantalla ejecutando un script en el contenido
        const [{ result: viewportOffset }] = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
                const uiHeaderHeight = window.outerHeight - window.innerHeight;
                return {
                    x: window.screenX + ((window.outerWidth - window.innerWidth) / 2),
                    y: window.screenY + uiHeaderHeight
                };
            }
        });

        const interactives = nodes.filter(n => {
            if (!n.role?.value || n.role.value === 'none' || n.role.value === 'generic') return false;
            if (!n.name?.value && !n.value?.value && !['textbox', 'searchbox', 'combobox'].includes(n.role.value)) return false;
            const roles = ['button', 'link', 'textbox', 'searchbox', 'combobox', 'menuitem', 'checkbox', 'radio', 'tab'];
            return roles.includes(n.role.value);
        });

        const affordances = [];
        let idCounter = 1;

        for (const n of interactives) {
            if (!n.backendDOMNodeId) continue;
            try {
                const nodeInfo = await chrome.debugger.sendCommand(target, 'DOM.resolveNode', { backendNodeId: n.backendDOMNodeId });
                if (nodeInfo && nodeInfo.object?.objectId) {
                    const box = await chrome.debugger.sendCommand(target, 'DOM.getBoxModel', { objectId: nodeInfo.object.objectId });
                    await chrome.debugger.sendCommand(target, 'Runtime.releaseObject', { objectId: nodeInfo.object.objectId });

                    if (box && box.model) {
                        const quad = box.model.border;
                        const vx = Math.min(quad[0], quad[2], quad[4], quad[6]);
                        const vy = Math.min(quad[1], quad[3], quad[5], quad[7]);
                        const vw = Math.max(quad[0], quad[2], quad[4], quad[6]) - vx;
                        const vh = Math.max(quad[1], quad[3], quad[5], quad[7]) - vy;

                        if (vw > 0 && vh > 0) {
                            const absX = viewportOffset.x + vx;
                            const absY = viewportOffset.y + vy;
                            affordances.push({
                                id: idCounter++,
                                role: n.role.value,
                                label: n.name?.value || n.value?.value || n.role.value,
                                type: n.role.value,
                                bbox: { x: absX, y: absY, w: vw, h: vh },
                                center: { x: absX + (vw / 2), y: absY + (vh / 2) }
                            });
                        }
                    }
                }
            } catch (ignore) { }
        }

        await chrome.debugger.detach(target);
        return {
            elements: affordances,
            app: 'browser',
            url: tabs[0].url,
            source: 'EXTENSION_CDP'
        };

    } catch (e) {
        // En caso de fallar, desacoplar limpiar estado
        try { await chrome.debugger.detach(target); } catch (e2) { }
        throw e;
    }
}
